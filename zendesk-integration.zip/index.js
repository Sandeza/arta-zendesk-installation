const httpClient = require('axios');

exports.handler = async (event) => {
    let customerNumber = await event.Details.ContactData.CustomerEndpoint.Address;
    let tickets = await getUserDetails(customerNumber);



    let customerInfo = tickets;
    return {
        "customerInfo": JSON.stringify(customerInfo)
    };

};


let getUserDetails = async (phoneNumber) => {


    try {
        const options = {
            "Content-Type": "application/json",
            "authorization": process.env.ACCESS_KEY + ":" + process.env.INTEGRATION_ID
        };



        let userDetails = await httpClient.get(`https://${process.env.URL}/integration/v1/helpdesk/contact/search/${phoneNumber}`, {
            headers: options
        });

        if (userDetails.data.message.id) {
            let user = userDetails.data.message;
            let userId = userDetails.data.message.id;
            let ticketData = await getTicketDetails(userId);

            let customerInfo = {
                "name": user.name,
                "id": user.id,
                "callFromNumber": user.phone,
                "tickets": ticketData
            };

            console.log(JSON.stringify(customerInfo));
            return customerInfo;

        }



    } catch (e) {
        let customerInfo = {
            id: 0,
            name: 'Unknown Caller',
            callFromNumber: 'undefined'
        };
        console.log(customerInfo);
        return customerInfo;

    }


};

let getTicketDetails = async (userId) => {


    try {

        const options = {
            "Content-Type": "application/json",
            "authorization": process.env.ACCESS_KEY + ":" + process.env.INTEGRATION_ID
        };

        let ticket = await httpClient.get(`https://${process.env.URL}/integration/v1/helpdesk/user/tickets/${userId}`, {
            headers: options
        });

        let tickets = ticket.data.message;
        let open = tickets.filter(ticket => ticket.status == 'open');
        let other = tickets.filter(ticket => ticket.status != 'open');
        let openTickets = open.map((op) => {
            return {
                "id": op.id,
                "status": op.status,
                "subject": op.subject
            };

        });

        let otherTickets = other.map((op) => {
            return {
                "id": op.id,
                "status": op.status,
                "subject": op.subject
            };

        });

        tickets = {
            "openTickets": openTickets,
            "otherTickets": otherTickets
        };

        return tickets;

    } catch (err) {
        console.log(err);
    }

};