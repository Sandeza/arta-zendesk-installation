

let httpClient = require('axios');

 let getUserDetails = async function(params){
                let phoneNumber = params;

                let options = {
                    auth:{
                        username : process.env.nameUser,
                        password: process.env.password
                    },
                    Headers:{
                        "Content-Type": "application",
                       
                    }
                
                };
                let config = httpClient.create(options);
                
                try{
                    let userDetails = await config.get(`${process.env.domainName}/api/v2/search.json?query=type:user ${phoneNumber}`);
                    if(userDetails.data.length >0){
                    let result ={"userDetails":userDetails.data.results};
                    
                    return {         "customerId": result.userDetails[0].id,
                                     "customerName": result.userDetails[0].name,
                                     "phoneNumber": result.userDetails[0].phone,
                                     "emailId": result.userDetails[0].email
                    };
                    
                    }else{
                        return "User not found";
                    }
                    
                }catch(err){
                    return err.response;
                }
                
 };
 
 module.exports = getUserDetails;