

let httpClient = require('axios');

 let getTicketDetails = async function(params){
                let phoneNumber = params;

                let options = {
                    auth:{
                        username : process.env.nameUser,
                        password: process.env.password
                    },
                    Headers:{
                        "Content-Type": "application",
                       
                    }
                
                };
                let config = httpClient.create(options);
                
                try{
                let ticketDetails =  await config.get(`${process.env.domainName}/api/v2/search.json?query=type:ticket ${phoneNumber}`);
                if(ticketDetails.data.length > 0){
                    
                    let result = {"ticketDetails": ticketDetails.data.results};
                    
                            return {
                                     "ticketId": result.ticketDetails[0].id,
                                     "subject":result.ticketDetails[0].subject,
                                     "description":result.ticketDetails[0]["description"],
                                      "status": result.ticketDetails[0]["status"],
                                     "priority": result.ticketDetails[0].priority,
                                     "created_At":result.ticketDetails[0].created_at,
                                     "updated_At":result.ticketDetails[0].updated_at};
                }else{
                    return "Tickets not found";
                }
                    
                }catch(err){
                    return err.response;
                }
                
 };
 
 module.exports = getTicketDetails;